/**
 * 12/04/2019 examen JavaScript - G2M P8
 * JavaScript 
 */
 
// Raster OpenStreetMap
var osm = new ol.layer.Tile({
  source: new ol.source.OSM()
});

// Map OpenLayers
const map = new ol.Map({
  target: 'map', // nom de la <div> HTML
  controls: ol.control.defaults().extend([
    new ol.control.OverviewMap({className: "ol-overviewmap"}), // Mini-map
    new ol.control.ScaleLine() // Echelle
  ]),
  layers: [osm], // Couches de la carte
  view: new ol.View({ // Vue initiale
    center: ol.proj.fromLonLat([2.72, 47.50]),
    zoom: 4
  })
});

/**
 * Visibilité des couches
 * @param checkbox 
 */
function setVisibility(checkbox) {  

  map.getLayers().forEach(function(layer) {
    switch (checkbox.id) {
      case 'cbOSM':
      if (layer == osm) 
        layer.setVisible(checkbox.checked);
      break;

      // Ajouter ici les instructions permettant de gerer la visibilité des couches raster esri

    }
  });
}