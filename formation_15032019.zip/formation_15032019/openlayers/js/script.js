// Fond de carte raster : OpenStreetMap
var osmLayer = new ol.layer.Tile({
    source: new ol.source.OSM()
})

// Vue initiale
var vueInitiale = new ol.View({
    center: ol.proj.fromLonLat([2.294481, 48.858370]), // Paris WGS84
    zoom: 6
})

// Ma carte OpenLayers
const map = new ol.Map({
    target: 'map', // id de la <div> HTML
    controls: ol.control.defaults().extend([
        new ol.control.OverviewMap({className: "ol-overviewmap"}), // Mini-map
        new ol.control.FullScreen(), // Plein-ecran
        new ol.control.ScaleLine({className: "ol-scale-line"}) // Echelle
    ]),
    layers: [osmLayer], // Liste des couches sur ma carte
    view: vueInitiale
});

// Mon évènement click sur la carte
map.on('click', function(event){alert('click!')});
