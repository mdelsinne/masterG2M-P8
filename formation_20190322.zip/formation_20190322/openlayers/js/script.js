// Fond de carte raster : OpenStreetMap
var osmLayer = new ol.layer.Tile({
    source: new ol.source.OSM()
})

// Vue initiale
var vueInitiale = new ol.View({
    center: ol.proj.fromLonLat([2.294481, 48.858370]), // Paris WGS84
    zoom: 6
})

// Ma carte OpenLayers
const map = new ol.Map({
    target: 'map', // id de la <div> HTML
    controls: ol.control.defaults().extend([
        new ol.control.OverviewMap({className: "ol-overviewmap"}), // Mini-map
        new ol.control.FullScreen(), // Plein-ecran
        new ol.control.ScaleLine({className: "ol-scale-line"}) // Echelle
    ]),
    layers: [osmLayer], // Liste des couches sur ma carte
    view: vueInitiale
});

// Mon évènement click sur la carte
map.on('click', function(event){alert('click!')});

/**
 * 18/03/2019
 * LES BASES DU JAVASCRIPT
 */

// ES6 (2015) : let pour déclarer une variable (var fonctionne toujours)
let maVariable = "Hello World";
console.log(maVariable); // String

maVariable = true; // Affectation d’une nouvelle valeur 'true' de type booléen
console.log(maVariable); // Boolean

maVariable = 0; // Affectation d’un Entier
while (maVariable <= 5) { // Boucle while, avec opérateur
  console.log(maVariable); // Integer
  maVariable++; // Incrémentation
}

// Création d'un objet JS -- C'est comme un .json !
maVariable = {
    nom : "toto", // propriété 'nom', valeur '"toto"' : string
    age : 40, // propriété 'age', valeur '40' : integer
    locataire : true // propriété 'locataire', valeur 'true' : bool
}
console.log(maVariable); // Object
  
// Affectation d'une nouvelle propriété à l'objet
maVariable.profession = "Apiculteur";
console.log(maVariable); // mon objet + ma propriété
  
maVariable.adresse = { // Affectation d’un objet comme propriété de ma variable
    street: "2, Rue Voltaire", // propriété 'street' : string
    city: "44000 Nantes", // propriété 'city' : string
    coordinate : { // propriété 'coordinate' : objet
      x: -1.5628,
      y: 47.2130
    }
}
console.log(maVariable);

// Création d'un objet JS -- C'est comme un .json !
maVariable = {
  nom : "toto", // propriété 'nom', valeur '"toto"' : string
  age : 40, // propriété 'age', valeur '40' : integer
  locataire : true, // propriété 'locataire', valeur 'true' : bool
  profession : "Apiculteur" // propriété 'profession', valeur 'Apiculteur' : string
}
console.log(maVariable); // Object

/**
 * Déclaration d'une fonction nommée maFonction
 */
function maFonction() {
    // Instructions de la fonction
    console.log("Instructions à exécuter");
}
maFonction(); // Appel de ma fonction

for (let i=0;i<=5;i++) { // Boucle for
    maFonction(); // Appel de ma fonction
}

/**
 * Déclaration d'une autre fonction avec paramètres
 * @param {description param1} param1 
 * @param {description param2} param2 
 * @param {description param3} param3
 */
function maFonctionAvecParams(param1, param2, param3) {
    // Instructions pouvant utiliser param1, param2, ...
    return "Nom : "+param1+"\nAge : "+param2+"\nProfession : "+param3; // valeur String retournée 
};
console.log(maFonctionAvecParams(maVariable.nom, maVariable.age,  maVariable.profession)); // appel de ma fonction avec params qui retourne un string
console.log(maFonctionAvecParams("martin", maVariable.age,  maVariable.profession));

// Affectation d'une fonction à l'objet --appelé aussi Method !
maVariable.getDescription = function() {
    // this indique qu’il s’agit de la propriété appartenant à l’objet stocké dans maVariable
    return "Nom : "+this.nom+"\nAge : "+this.age+"\nProfession : "+this.profession; // valeur String retournée 
};
console.log(maVariable);
console.log(maVariable.getDescription());

// Afficher la description dans <p> dont l'identifiant est 'description' 
document.getElementById("description").textContent = maVariable.getDescription();

// Ma classe JS nommée Person
class Person {

  // 5 propriétés de l'objet initialisées par le constructeur
  constructor(nom, age, locataire, profession, adresse) {
    this.nom = nom; 
    this.age = age;
    this.locataire = locataire;
    this.profession = profession;
    this.adresse = adresse;
  }
  
  // Méthode disponible pour un objet Person
  getDescription() {
    return "Nom : "+this.nom+"\nAge : "+this.age+"\nProfession : "+this.profession;
  }

  // Autre méthode disponible pour un objet Person -- avec 3 paramètres en entrée
  setAdresse(paramStreet, paramCity, paramCoord) {
    // La fonction ajoute la propriété 'adresse' à l'objet instancié depuis la classe Person
    this.adresse = { // les valeurs de l'objet sont initialisés depuis les paramètres en entrée
      street: paramStreet,
      city: paramCity,
      coordinate : ol.proj.fromLonLat([paramCoord.x,paramCoord.y]) // La method fromLonLat attend un objet ol.coordinate(Array.<number>) en paramètre obligatoire 
    }
  }
};

// Instanciation d'un nouvel objet Person
maVariable = new Person("toto", 40, true, "Apiculteur", null);
console.log(maVariable);
// var autreVariable = new Person(NOM_string, AGE_integer, LOCATAIRE_boolean, PROFESSION_string)
// console.log(autreVariable);

// Utiliser la fonction setAdresse pour initialiser la propriété 'adresse'
// de mon objet instance de Person stocké dans maVariable
maVariable.setAdresse(
  "2, Rue Voltaire",
  "44000 Nantes", 
  {x: -1.5628,y: 47.2130}
);
console.log(maVariable);

// Déclaration d'un tableaux [...]
var monTableau = [
  // 1 er élément : 
  maVariable,
  // 2nd élément :
  new Person( //objet instancié de la classe Person
    "Pierre", // Propriété 1 du constructeur
    38, // Propriété 2 du constructeur
    false, // Propriété 3 du constructeur
    "Artisan", // Propriété 4 du constructeur
    { // 5 ème propriété : objet
      street:"7, rue Victor Hugo", 
      city:"93100 Montreuil", 
      coordinate:{x:2.439568,y:48.859413}
    }
  ), // virgule comme séparateur
  // 3ème élément :
  new Person("Paul", 31, true, "Médecin",{
	  street:"169, rue de Bellevue", city:"92700 Colombes", coordinate:{x:2.236667,y:48.919502} 
  }) // pas de virgule car dernier
]

console.log(monTableau);
console.log(monTableau.length); // nombre d'élément

// Ajouter un élément : push
monTableau.push(new Person("Jack", 54, true, "Technicien",
  { // propriété adresse de mon objet
    street:"37, avenue Carnot", 
    city:"94230 Cachan", 
    coordinate:{
      x:2.327411,
      y:48.798287
    }
  }
));

console.log(monTableau);
console.log(monTableau.length);

// splice(index où commence la suppression, nombre d'élément à supprimer)
//monTableau.splice(1,1); // supprime le 2nd élément du tableau
monTableau.shift(); // supprime le 1er élément du tableau
console.log(monTableau);

// Accèder à un élément
console.log(monTableau[1].getDescription());
monTableau[1].nom = "Paule"; // modifier une valeur
console.log(monTableau[1].getDescription());

/** myArray.shift(); // Retire le premier élément */
/** myArray.pop(); // Retire le dernier élément */

// Parcourir le tableau, boucle for
for (var i=0;i<monTableau.length;i++) {
  console.log( "indice : "+i.toString()+" nom : "+monTableau[i].nom);
}

// Parcourir les éléments du tableau
for (var i=0;i<monTableau.length;i++) {
  if (monTableau[i].locataire == true && monTableau[i].age < 40) {
    console.log("locataire de moins de 40 ans : \n" + monTableau[i].getDescription());
  } else if (monTableau[i].locataire == true) {
    console.log("locataire de plus de 40 ans : \n" + monTableau[i].getDescription());
  } else {
    console.log("propriétaire : \n" + monTableau[i].getDescription());
  }
}